// bindings/README
// This directory is intended to store generated FFI bindings.
//
// Example (planned):
//   astrac c-import /usr/include/stdio.h --link c -o bindings/c_stdio.astr
